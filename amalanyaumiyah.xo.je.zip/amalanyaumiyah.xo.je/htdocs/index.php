<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Kustom Anda</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            max-width: 500px;
        }
        img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        p {
            font-size: 1.1em;
            color: #333;
            line-height: 1.6;
        }
        code {
            background-color: #eef1f4;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
        <img src="contoh-url.jpg" alt="Contoh URL Kustom">
        
        <p>
            Anda dapat mengakses halaman personal Anda dengan mengganti bagian <code>/rasyid</code> pada URL dengan nama Anda yang sudah terdaftar.
        </p>
        <p>
            Sebagai contoh: <strong>https://amalanumiyah.xo.je/nama-anda</strong>
        </p>
    </div>

</body>
</html>
