<?php
// FILE: index.php (VERSI FINAL DENGAN SEMUA FITUR TERMASUK PERHITUNGAN ASLI VIA CLASS)

// --- PENGATURAN DASAR ---
date_default_timezone_set('Asia/Jakarta');
// MODIFIKASI 1: Cek apakah $dataFile sudah didefinisikan oleh file pemanggil.
// Jika belum, gunakan default (file di folder ini sendiri).
if (!isset($dataFile)) {
    $dataFile = __DIR__ . '/data_amalan.json';
}
// __DIR__ adalah konstanta PHP yang berarti "direktori dari file ini".
// Ini memastikan path akan selalu benar, tidak peduli dari mana file ini di-include.


// --- FUNGSI BARU UNTUK MENGGUNAKAN CLASS PERHITUNGAN ---
function getAyyamulBidhInfoFromClass() {
    // MODIFIKASI 2: Gunakan __DIR__ untuk include/require.
    require_once __DIR__ . '/AyamulBidhCalc.php'; 
    $calculator = new AyyamulBidhCalculator();
    
    // 2. Panggil method untuk mendapatkan data Ayyamul Bidh.
    $bidhData = $calculator->getAyyamulBidhDates();
    
    $jadwal_puasa_final = [];
    if (empty($bidhData['error']) && !empty($bidhData['dates'])) {
        foreach ($bidhData['dates'] as $dateInfo) {
            // Menggunakan format tanggal yang sudah disediakan oleh class
            $jadwal_puasa_final[] = $dateInfo['formatted'];
        }
    }

    // 3. Menyusun informasi lengkap untuk ditampilkan.
    return [
        'title'       => 'Puasa Ayyamul Bidh (Puasa Hari-hari Putih)',
        'description' => 'Puasa sunnah yang dilaksanakan pada tanggal 13, 14, dan 15 setiap bulan Hijriah. Disebut hari-hari putih karena pada malam-malam tersebut, bulan bersinar terang menyinari bumi.',
        'hadith'      => 'Dari Abu Dzar, Rasulullah shallallahu ‘alaihi wa sallam bersabda padanya, “Jika engkau ingin berpuasa tiga hari setiap bulannya, maka berpuasalah pada tanggal 13, 14, dan 15 (dari bulan Hijriyah).” (HR. Tirmidzi dan An Nasa’i)',
        'dates_title' => 'Perkiraan Jadwal Bulan Ini (' . ($bidhData['current_hijri_month'] ?? '') . ' ' . ($bidhData['current_hijri_year'] ?? '') . '):',
        'dates'       => $jadwal_puasa_final,
        'disclaimer'  => 'Perhitungan ini menggunakan algoritma internal dan akurasinya bisa berbeda satu hari, tergantung metode penentuan awal bulan (rukyat/hisab) di wilayah Anda.'
    ];
}

// Panggil fungsi untuk mendapatkan data dinamis setiap kali halaman dimuat
$ayyamul_bidh_info = getAyyamulBidhInfoFromClass();


// --- STRUKTUR DATA AMALAN ---
$daftar_amalan = [
    'SHOLAT WAJIB' => [
        'subuh' => 'Subuh', 'dzuhur' => 'Dzuhur', 'ashar' => 'Ashar', 'maghrib' => 'Maghrib', 'isya' => 'Isya'
    ],
    'SHOLAT SUNNAH' => [
        'rawatib' => 'Rawatib', 'dhuha' => 'Dhuha', 'tahajud' => 'Tahajud'
    ],
    'PUASA SUNNAH' => [
        'senin_kamis' => 'Senin/Kamis', 'ayamul_bidh' => 'Ayyamul Bidh'
    ],
    'TILAWAH' => [
        'tilawah' => 'Tilawah Quran'
    ],
    'SEDEKAH' => [
        'sedekah' => 'Sedekah'
    ],
    'ALMATSURAT' => [
        'almatsurat_pagi' => 'Al-Matsurat Pagi', 'almatsurat_petang' => 'Al-Matsurat Petang'
    ],
    'ISTIGHFAR' => [
        'istighfar' => 'Istighfar'
    ]
];

// Opsi detail untuk Rawatib (HANYA MU'AKAD SESUAI ANJURAN)
$rawatib_details = [
    'rawatib_subuh_q' => '2 Rakaat sebelum Subuh',
    'rawatib_dzuhur_q' => '2 atau 4 Rakaat sebelum Dzuhur',
    'rawatib_dzuhur_b' => '2 Rakaat setelah Dzuhur',
    'rawatib_maghrib_b' => '2 Rakaat setelah Maghrib',
    'rawatib_isya_b' => '2 Rakaat setelah Isya'
];


// --- FUNGSI-FUNGSI ---
function bacaDataAmalan($file) {
    if (!file_exists($file)) file_put_contents($file, '{}');
    $dataJson = file_get_contents($file);
    return json_decode($dataJson, true) ?: [];
}

function simpanDataAmalan($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Fungsi untuk memberikan kelas warna pada sel tabel
function getCellColorClass($key, $value) {
    if (empty($value)) return 'status-empty';

    switch ($key) {
        case 'subuh':
        case 'dzuhur':
        case 'ashar':
        case 'maghrib':
        case 'isya':
            if ($value == 'M') return 'status-good'; // Masjid Jamaah
            if ($value == 'R-J') return 'status-ok-2'; // Rumah Jamaah
            if ($value == 'M-S') return 'status-ok-1'; // Masjid Sendiri
            if ($value == 'R') return 'status-ok-1'; // Rumah Sendiri
            if (strpos($value, 'Q') === 0) return 'status-qadha'; // Qadha (baik 'Q' maupun 'Q (...)')
            return 'status-empty';
        case 'rawatib':
            list($done, $total) = explode('/', $value);
            if ($done == $total) return 'status-good';
            if ($done > 0) return 'status-ok-2';
            return 'status-empty';
        case 'istighfar':
            if ($value >= 200) return 'status-good';
            if ($value >= 100) return 'status-ok-2';
            return 'status-empty';
        case 'tilawah':
            return 'status-ok-2'; // Setiap tilawah dianggap baik
        default:
            return 'status-good'; // Untuk checkbox ✓
    }
}


// --- PROSES SUBMIT FORM ---
$pesan_sukses = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tanggal'])) {
    $tanggal = $_POST['tanggal'];
    $bulan = date('Y-m', strtotime($tanggal));
    $hari = (int)date('d', strtotime($tanggal));

    $dataAmalan = bacaDataAmalan($dataFile);

    // Proses semua amalan standar (Sholat Wajib, Dhuha, Tahajud, dll)
    foreach ($daftar_amalan as $kategori) {
        foreach ($kategori as $key => $label) {
            $dataAmalan[$bulan][$key][$hari] = $_POST[$key] ?? '';
        }
    }
    
    // --- PROSES INPUT DETAIL (TIDAK MERUSAK INTI) ---
    // 1. Sedekah
    if (!empty($_POST['sedekah']) && !empty($_POST['sedekah_detail'])) {
        $dataAmalan[$bulan]['sedekah'][$hari] = '✓ (' . trim($_POST['sedekah_detail']) . ')';
    }
    // 2. Al-Matsurat Pagi
    if (!empty($_POST['almatsurat_pagi']) && !empty($_POST['almatsurat_pagi_detail'])) {
        $dataAmalan[$bulan]['almatsurat_pagi'][$hari] = '✓ (' . trim($_POST['almatsurat_pagi_detail']) . ')';
    }
    // 3. Al-Matsurat Petang
    if (!empty($_POST['almatsurat_petang']) && !empty($_POST['almatsurat_petang_detail'])) {
        $dataAmalan[$bulan]['almatsurat_petang'][$hari] = '✓ (' . trim($_POST['almatsurat_petang_detail']) . ')';
    }


    // Proses input khusus
    // 1. Tilawah: gabungkan surat dan ayat
    if (!empty($_POST['tilawah_surat'])) {
        $tilawah_text = trim($_POST['tilawah_surat']);
        if(!empty($_POST['tilawah_ayat_mulai'])) {
            $tilawah_text .= ' ' . trim($_POST['tilawah_ayat_mulai']);
            if(!empty($_POST['tilawah_ayat_selesai'])) {
                 $tilawah_text .= '-' . trim($_POST['tilawah_ayat_selesai']);
            }
        }
        $dataAmalan[$bulan]['tilawah'][$hari] = $tilawah_text;
    } else {
        $dataAmalan[$bulan]['tilawah'][$hari] = '';
    }

    // 2. Rawatib: hitung jumlah yang dichecklist
    $rawatib_done = 0;
    foreach ($rawatib_details as $key => $label) {
        if (!empty($_POST[$key])) {
            $rawatib_done++;
            $dataAmalan[$bulan][$key][$hari] = '✓'; // Simpan detailnya juga
        } else {
             $dataAmalan[$bulan][$key][$hari] = '';
        }
    }
    $dataAmalan[$bulan]['rawatib'][$hari] = ($rawatib_done > 0) ? $rawatib_done . '/' . count($rawatib_details) : '';

    // 3. Istighfar: simpan nilainya langsung
    $istighfar_val = (int)($_POST['istighfar'] ?? 0);
    $dataAmalan[$bulan]['istighfar'][$hari] = $istighfar_val > 0 ? $istighfar_val : '';


    simpanDataAmalan($dataFile, $dataAmalan);
    $pesan_sukses = "Data untuk tanggal " . date('d F Y', strtotime($tanggal)) . " berhasil disimpan!";
}

// --- PERSIAPAN DATA UNTUK DITAMPILKAN ---
$bulan_sekarang = date('Y-m');
$semuaDataAmalan = bacaDataAmalan($dataFile);
$dataBulanIni = $semuaDataAmalan[$bulan_sekarang] ?? [];
$jumlah_hari = date('t');

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tracker Amalan Yaumiyah</title>
    <?php
// Cek apakah variabel $manifestPath didefinisikan (menandakan kita di subfolder).
if (isset($manifestPath)) {
    // Jika di subfolder, HANYA cetak link manifest jika path-nya tidak kosong.
    if (!empty($manifestPath)) {
        echo '<link rel="manifest" href="' . htmlspecialchars($manifestPath) . '">';
    }
    // Jika $manifestPath kosong atau tidak ada, maka subfolder tidak akan punya manifest.
} else {
    // Jika kita TIDAK di subfolder (di folder induk), gunakan manifest default.
    echo '<link rel="manifest" href="https://krasyid822.github.io/Drive/manifest.json">';
}
?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        /* --- PALET WARNA & FONT MODERN --- */
        :root {
            --color-primary: #4a90e2; /* Biru yang lebih modern */
            --color-primary-dark: #357ABD;
            --color-secondary: #f4f8fe;
            --color-background: #f8f9fa;
            --color-surface: #ffffff;
            --color-text: #343a40;
            --color-text-light: #6c757d;
            --color-border: #e3e8ee;
            --font-family: 'Poppins', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;

            /* Status Colors (lebih lembut) */
            --color-good: #e0f8e9; --color-good-text: #1d7a46;
            --color-ok-2: #ddebfd; --color-ok-2-text: #2a69c2;
            --color-ok-1: #fff8e1; --color-ok-1-text: #a07f2d;
            --color-qadha: #fde8e9; --color-qadha-text: #c23b42;
            --color-empty: #f8f9fa; --color-empty-text: #6c757d;
        }

        /* --- GLOBAL & BODY --- */
        html { scroll-behavior: smooth; }
        body {
            font-family: var(--font-family);
            margin: 0;
            background-color: var(--color-background);
            color: var(--color-text);
            line-height: 1.6;
            padding-bottom: 120px; /* Add padding to prevent content from being hidden by floating button */
        }

        /* --- CONTAINER & LAYOUT --- */
        .container {
            max-width: 1300px;
            margin: 30px auto;
            padding: 20px 30px;
        }
        .main-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .main-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--color-text);
        }
        .main-header p {
            font-size: 1.1rem;
            color: var(--color-text-light);
            margin-top: -15px;
        }
        
        /* --- STYLE UNTUK NAMA PENGGUNA --- */
        .nama-pengguna {
            display: inline-block;
            background-color: #6c757d; /* Warna abu-abu dari variabel --color-text-light */
            color: #ffffff;
            padding: 5px 20px;
            border-radius: 25px; /* Membuat bentuk pil yang menawan */
            margin-top: 15px;
            font-size: 1.1rem;
            font-weight: 500;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.2s ease;
        }
        .nama-pengguna:hover {
            transform: scale(1.05);
        }

        /* --- FORM CONTAINER --- */
        .form-container {
            background-color: var(--color-surface);
            padding: 30px;
            border-radius: 16px;
            margin-bottom: 40px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--color-border);
        }
        h2 {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--color-border);
            text-align: left;
        }
        
        /* --- QUICK NAVIGATION --- */
        .quick-nav {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 30px;
            padding-bottom: 25px;
            border-bottom: 1px solid var(--color-border);
        }
        .nav-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            border-radius: 8px;
            background-color: var(--color-secondary);
            color: var(--color-text-light);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            border: 1px solid var(--color-border);
            transition: all 0.2s ease-in-out;
        }
        .nav-button i { font-size: 1.1em; }
        .nav-button:hover {
            background-color: var(--color-primary);
            color: white;
            border-color: var(--color-primary);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(74, 144, 226, 0.2);
        }

        /* --- FORM ELEMENTS --- */
        fieldset {
            border: none;
            padding: 0;
            margin: 0;
            margin-bottom: 35px; /* Jarak antar kategori */
        }
        fieldset:last-of-type { margin-bottom: 0; }

        legend {
            font-weight: 600;
            color: var(--color-primary);
            padding-bottom: 15px;
            margin-bottom: 15px;
            font-size: 1.3em;
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            border-bottom: 1px dashed var(--color-border);
        }
        .form-group { margin-bottom: 20px; }
        label { font-weight: 500; font-size: 0.95rem; margin-bottom: 8px; display: block; }
        input[type="date"], input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--color-border);
            border-radius: 8px;
            box-sizing: border-box;
            background-color: #fff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        input:focus, select:focus {
            outline: none;
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }
        
        /* --- PRAYER CYCLE BUTTON & SUN EFFECT --- */
        .prayer-inputs-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .prayer-input-group {
            display: flex;
            flex-direction: column;
            padding: 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        .prayer-input-group label {
            font-weight: 600;
            font-size: 1rem;
            margin-bottom: 10px;
            color: white;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.4);
        }
        /* Sun Position Gradients */
        .prayer-time-subuh { background: linear-gradient(180deg, #3a5b8a 0%, #fbc2a6 100%); }
        .prayer-time-dzuhur { background: linear-gradient(180deg, #87CEEB 0%, #B2FFFF 100%); }
        .prayer-time-ashar { background: linear-gradient(180deg, #4682B4 0%, #a2c4d8 100%); }
        .prayer-time-maghrib { background: linear-gradient(180deg, #ff7e5f 0%, #feb47b 100%); }
        .prayer-time-isya { background: linear-gradient(180deg, #0F2027 0%, #203A43 50%, #2C5364 100%); }
        
        .prayer-cycle-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 2px solid transparent;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(4px);
            color: var(--color-text);
        }
        .prayer-cycle-btn i { font-size: 1.1em; }
        .prayer-cycle-btn.status-M { border-color: var(--color-good-text); color: var(--color-good-text); }
        .prayer-cycle-btn.status-R-J { border-color: var(--color-ok-2-text); color: var(--color-ok-2-text); }
        .prayer-cycle-btn.status-M-S, .prayer-cycle-btn.status-R { border-color: var(--color-ok-1-text); color: var(--color-ok-1-text); }
        .prayer-cycle-btn.status-Q { border-color: var(--color-qadha-text); color: var(--color-qadha-text); }
        .prayer-cycle-btn.status-empty { border-color: rgba(0,0,0,0.1); color: var(--color-text-light); font-weight: 500;}

        /* --- CUSTOM CHECKBOX & NEW DETAIL INPUT --- */
        .checkbox-group { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
        .checkbox-group label { margin-bottom: 0; font-weight: 400; cursor: pointer; }
        .checkbox-group input[type="checkbox"] { margin-right: 4px; width: 18px; height: 18px; accent-color: var(--color-primary); cursor: pointer; }
        .optional-input-wrapper {
            margin-top: 10px;
            transition: all 0.3s ease;
        }
        .info-btn {
            background: none;
            border: none;
            color: var(--color-primary);
            cursor: pointer;
            padding: 0 5px;
            font-size: 1.1rem;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        .info-btn:hover { opacity: 1; }
        
        .tilawah-grid { display: grid; gap: 10px; grid-template-columns: 1fr 90px 90px; }
        .rawatib-grid { display: grid; gap: 12px; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
        .form-group-columns { display: grid; gap: 20px; grid-template-columns: 1fr 1fr;}

        /* --- BUTTONS --- */
        .submit-btn {
            display: block; width: 100%; padding: 15px; background: linear-gradient(45deg, var(--color-primary), #28a745); color: white; border: none;
            border-radius: 8px; font-size: 1.1rem; font-weight: 600; cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(74, 144, 226, 0.3);
        }
        .original-submit-wrapper {
            margin-top: 20px;
            transition: opacity 0.3s, visibility 0.3s;
        }
        .download-btn {
            display: inline-flex; align-items: center; gap: 8px; text-decoration: none; background-color: var(--color-primary); color: white;
            padding: 12px 20px; border-radius: 8px; margin-top: 20px; font-weight: 500; transition: background-color 0.2s;
        }
        .download-btn:hover { background-color: var(--color-primary-dark); }
        
        /* --- FLOATING SAVE BUTTON --- */
        .floating-save-container {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 15px 0;
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.08);
            z-index: 1000;
            transform: translateY(150%);
            transition: transform 0.4s ease-in-out;
            border-top: 1px solid var(--color-border);
        }
        .floating-save-container .container {
            margin: 0 auto;
            padding-top: 0;
            padding-bottom: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }
        .floating-save-container p {
            margin: 0;
            font-weight: 500;
            color: var(--color-text);
        }
        .floating-save-container .submit-btn {
            min-width: 200px;
            width: auto;
        }
        body.show-floating-save .floating-save-container {
            transform: translateY(0);
        }
        body.show-floating-save .original-submit-wrapper {
            opacity: 0;
            visibility: hidden;
        }
        
        /* --- MODAL FOR AYYAMUL BIDH INFO --- */
        .modal-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease-in-out;
        }
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            position: relative;
            transform: translateY(-20px);
            transition: all 0.3s ease-in-out;
        }
        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }
        .modal-close-btn {
            position: absolute;
            top: 10px; right: 15px;
            background: none;
            border: none;
            font-size: 2rem;
            color: #aaa;
            cursor: pointer;
        }
        .modal-content h3 { margin-top: 0; color: var(--color-primary); }
        .modal-content p { color: var(--color-text-light); font-style: italic; }
        .modal-content .disclaimer { font-size: 0.8rem; font-style: normal; margin-top:15px; color: #aaa; }
        .modal-content h4 { margin-bottom: 10px; }
        .modal-content ul { padding-left: 20px; margin: 0; }
        .modal-content li { margin-bottom: 8px; }


        /* --- PESAN & NOTIFIKASI --- */
        .pesan {
            padding: 18px; border-radius: 10px; text-align: center; margin: 25px 0; border: 1px solid;
            font-size: 1rem; font-weight: 500;
        }
        .pesan-sukses { background-color: var(--color-good); color: var(--color-good-text); border-color: #b8e9c9; }
        .pesan-pengingat {
            background-color: var(--color-ok-1); color: var(--color-ok-1-text); border-color: #ffeeba;
            display: flex; flex-direction: column; align-items: center; gap: 15px;
        }
        .pesan-pengingat strong { font-size: 1.2rem; }

        /* --- LAPORAN TABLE --- */
        .table-container {
            background-color: var(--color-surface);
            padding: 30px;
            border-radius: 16px;
            margin-top: 40px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--color-border);
        }
        .table-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        table {
            width: 100%; border-collapse: collapse; margin-top: 20px;
            border-radius: 12px; overflow: hidden;
        }
        th, td { border: 1px solid var(--color-border); padding: 12px 10px; text-align: center; min-width: 50px; font-size: 0.9rem; }
        th {
            background-color: #f9fafb; font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px;
            color: var(--color-text-light); position: sticky; top: -1px; z-index: 10;
        }
        td { transition: background-color: 0.3s; }
        tr:not(.kategori-row):hover td { background-color: #f5f5f5 !important; }

        .th-ibadah, .td-ibadah { text-align: left; min-width: 130px; font-weight: 500; }
        td.td-ibadah { vertical-align: top; }
        .td-ibadah small { color: var(--color-text-light); font-size: 0.85em; }
        .kategori-utama { font-weight: 700; background-color: #f1f3f5; }
        .td-kategori-header { vertical-align: middle; }

        /* --- TABLE CELL STATUS COLORS --- */
        .status-good { background-color: var(--color-good); color: var(--color-good-text); font-weight: 600; }
        .status-ok-2 { background-color: var(--color-ok-2); color: var(--color-ok-2-text); }
        .status-ok-1 { background-color: var(--color-ok-1); color: var(--color-ok-1-text); }
        .status-qadha { background-color: var(--color-qadha); color: var(--color-qadha-text); }
        .status-empty { background-color: var(--color-surface); }

        /* --- PANEL PENJELASAN (KARTU FITUR) --- */
        #penjelasan-fitur {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: 40px;
            padding: 0;
            background: none;
            border: none;
        }
        .feature-card {
            background-color: var(--color-surface);
            padding: 25px;
            border-radius: 12px;
            border: 1px solid var(--color-border);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.07);
        }
        .feature-card h3 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--color-primary);
        }
        .feature-card p, .feature-card ul { color: var(--color-text-light); }
        .feature-card ul { padding-left: 20px; margin: 0; }
        .feature-card li { margin-bottom: 8px; }
        .feature-card li strong { color: var(--color-text); }
        
        /* --- ISTIGHFAR SLIDER --- */
        .istighfar-group {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 10px;
        }
        #istighfar_slider { flex-grow: 1; }
        #istighfar_value {
            font-weight: 600;
            color: var(--color-primary);
            background: var(--color-secondary);
            padding: 4px 12px;
            border-radius: 6px;
            min-width: 40px;
            text-align: center;
        }

    </style>
</head>
<body>
    <?php include __DIR__ . '/shortcuts.php'; ?>

<div class="container">
    <header class="main-header">
        <h1>Tracker Amalan Yaumiyah</h1>
        <p>Catat dan pantau ibadah harianmu untuk menjadi lebih istiqomah.</p>
        
        <?php
// Tentukan nama yang akan ditampilkan.
// Jika $namaPengguna ada (dari subfolder), gunakan itu. Jika tidak, gunakan nama default.
$displayName = isset($namaPengguna) ? $namaPengguna : 'Rasyid Kurniawan';
?>
<div class="nama-pengguna"><?= htmlspecialchars($displayName) ?></div>
    </header>

    <div id="reminder-container"></div>

    <div class="form-container">
        <h2><i class="fa-solid fa-pen-to-square"></i> Input & Edit Amalan Harian</h2>
        
        <?php if ($pesan_sukses): ?>
            <div class="pesan pesan-sukses"><?= htmlspecialchars($pesan_sukses) ?></div>
        <?php endif; ?>

        <form id="form-amalan" action="" method="POST">
            <div class="form-group">
                <label for="tanggal">Pilih Tanggal:</label>
                <input type="date" id="tanggal" name="tanggal" value="<?= date('Y-m-d') ?>" required>
            </div>
            
            <nav class="quick-nav">
                <a href="#form-sholat-wajib" class="nav-button"><i class="fa-solid fa-mosque"></i> Sholat Wajib</a>
                <a href="#form-sholat-sunnah" class="nav-button"><i class="fa-solid fa-hands-praying"></i> Sholat Sunnah</a>
                <a href="#form-tilawah" class="nav-button"><i class="fa-solid fa-book-quran"></i> Tilawah</a>
                <a href="#form-istighfar" class="nav-button"><i class="fa-solid fa-person-praying"></i> Istighfar</a>
                <a href="#form-puasa" class="nav-button"><i class="fa-solid fa-moon"></i> Puasa Sunnah</a>
                <a href="#form-sedekah" class="nav-button"><i class="fa-solid fa-hand-holding-dollar"></i> Sedekah</a>
                <a href="#form-almatsurat" class="nav-button"><i class="fa-solid fa-shield-halved"></i> Al-Ma'tsurat</a>
            </nav>

            <fieldset id="form-sholat-wajib">
                <legend><i class="fa-solid fa-mosque"></i>Sholat Wajib <?= generate_shortcut_link('SHOLAT WAJIB') ?></legend>
              <div class="prayer-inputs-container">
    <?php foreach($daftar_amalan['SHOLAT WAJIB'] as $key => $label): ?>
    <div class="prayer-input-group prayer-time-<?= $key ?>">
        <label><?= $label ?></label>
        <button type="button" id="btn-<?= $key ?>" class="prayer-cycle-btn" data-key="<?= $key ?>">
            </button>
        <input type="hidden" name="<?= $key ?>" id="input-<?= $key ?>" value="">
        
        <div class="qadha-details-wrapper" id="qadha-details-<?= $key ?>" style="display: none; margin-top: 10px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <input type="date" class="qadha-date-input" data-key="<?= $key ?>" aria-label="Tanggal Qadha <?= $label ?>">
            <input type="time" class="qadha-time-input" data-key="<?= $key ?>" aria-label="Waktu Qadha <?= $label ?>">
        </div>

    </div>
    <?php endforeach; ?>
</div>
            </fieldset>

            <fieldset id="form-sholat-sunnah">
                <legend><i class="fa-solid fa-hands-praying"></i>Sholat Sunnah</legend>
                <label>Rawatib Mu'akkad</label>
                <div class="rawatib-grid">
                    <?php foreach($rawatib_details as $key => $label): ?>
                    <div class="checkbox-group">
                        <input type="checkbox" id="<?= $key ?>" name="<?= $key ?>">
                        <label for="<?= $key ?>"><?= $label ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>
                <hr style="margin: 20px 0; border-color: var(--color-border);">
                <div class="form-group-columns">
                    <?php foreach(['dhuha', 'tahajud'] as $key): ?>
                    <div class="form-group checkbox-group">
                        <input type="checkbox" id="<?= $key ?>" name="<?= $key ?>" value="✓">
                        <label for="<?= $key ?>"><?= $daftar_amalan['SHOLAT SUNNAH'][$key] ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>
            </fieldset>
            
            <fieldset id="form-tilawah">
                <legend><i class="fa-solid fa-book-quran"></i>Tilawah Quran</legend>
                <div class="tilawah-grid">
                   <input type="text" id="tilawah_surat" name="tilawah_surat" placeholder="Nama Surat">
                   <input type="text" id="tilawah_ayat_mulai" name="tilawah_ayat_mulai" placeholder="Ayat Ke">
                   <input type="text" id="tilawah_ayat_selesai" name="tilawah_ayat_selesai" placeholder="Sampai Ke">
                </div>
            </fieldset>

            <fieldset id="form-istighfar">
                <legend><i class="fa-solid fa-person-praying"></i>Istighfar <?= generate_shortcut_link('ISTIGHFAR') ?></legend>
                <input type="number" id="istighfar" name="istighfar" min="0" max="200" placeholder="Jumlah" style="display:none;">
                <div class="istighfar-group">
                    <input type="range" id="istighfar_slider" min="0" max="200" step="10" value="0">
                    <span id="istighfar_value">0</span>
                </div>
            </fieldset>
            
            <fieldset id="form-puasa">
                <legend><i class="fa-solid fa-moon"></i>Puasa Sunnah</legend>
                <div class="form-group-columns">
                    <?php foreach($daftar_amalan['PUASA SUNNAH'] as $key => $label): ?>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="<?= $key ?>" name="<?= $key ?>" value="✓">
                            <label for="<?= $key ?>"><?= $label ?></label>
                            <?php if($key === 'ayamul_bidh'): ?>
                                <button type="button" class="info-btn" id="ayamul_bidh_info_btn"><i class="fa-solid fa-circle-info"></i></button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </fieldset>
            
            <fieldset id="form-sedekah">
                <legend><i class="fa-solid fa-hand-holding-dollar"></i>Sedekah</legend>
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="sedekah" name="sedekah" value="✓" data-details-wrapper="sedekah_details_wrapper">
                        <label for="sedekah">Sedekah</label>
                    </div>
                    <div class="optional-input-wrapper" id="sedekah_details_wrapper" style="display: none;">
                        <input type="text" name="sedekah_detail" id="sedekah_detail" placeholder="Opsional: Tulis jenis sedekah (cth: Uang, Nasi kotak)">
                    </div>
                </div>
            </fieldset>
            
            <fieldset id="form-almatsurat">
                <legend><i class="fa-solid fa-shield-halved"></i>Al-Ma'tsurat <?= generate_shortcut_link('ALMATSURAT') ?></legend>
                <div class="form-group-columns">
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="almatsurat_pagi" name="almatsurat_pagi" value="✓" data-details-wrapper="almatsurat_pagi_details_wrapper">
                            <label for="almatsurat_pagi">Al-Ma'tsurat Pagi</label>
                        </div>
                        <div class="optional-input-wrapper" id="almatsurat_pagi_details_wrapper" style="display: none;">
                            <input type="text" name="almatsurat_pagi_detail" id="almatsurat_pagi_detail" placeholder="Opsional: sampai bagian mana">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="almatsurat_petang" name="almatsurat_petang" value="✓" data-details-wrapper="almatsurat_petang_details_wrapper">
                            <label for="almatsurat_petang">Al-Ma'tsurat Petang</label>
                        </div>
                        <div class="optional-input-wrapper" id="almatsurat_petang_details_wrapper" style="display: none;">
                            <input type="text" name="almatsurat_petang_detail" id="almatsurat_petang_detail" placeholder="Opsional: sampai bagian mana">
                        </div>
                    </div>
                </div>
            </fieldset>

            <div class="original-submit-wrapper">
                 <button type="submit" class="submit-btn">Simpan Data</button>
            </div>
        </form>
    </div>

    <div class="table-container">
        <h2>Laporan Bulan: <?= date('F Y') ?></h2>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th rowspan="2">NO</th>
                        <th rowspan="2" colspan="2" class="th-ibadah">IBADAH</th>
                        <th colspan="<?= $jumlah_hari ?>">TANGGAL</th>
                    </tr>
                    <tr>
                        <?php for ($i = 1; $i <= $jumlah_hari; $i++): ?><th><?= $i ?></th><?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $nomor = 1;
                    foreach ($daftar_amalan as $kategori => $sub_kategori): 
                        $jumlah_sub = count($sub_kategori);
                        $is_first_row_in_category = true;
                    ?>
                    
                    <?php 
                    foreach ($sub_kategori as $key => $label):
                    ?>
                    <tr class="kategori-row">
                        <?php if ($is_first_row_in_category): ?>
                        <td class="kategori-utama td-kategori-header" rowspan="<?= $jumlah_sub ?>"><?= $nomor++ ?></td>
                        <td class="kategori-utama td-kategori-header td-ibadah" rowspan="<?= $jumlah_sub ?>"><?= htmlspecialchars($kategori) ?></td>
                        <?php endif; ?>
                        
                        <td class="td-ibadah"><?= htmlspecialchars($label) ?></td>
                        
                        <?php for ($i = 1; $i <= $jumlah_hari; $i++): 
                            $value = $dataBulanIni[$key][$i] ?? '';
                            if($key == 'istighfar') {
                                if ($value >= 200) $display_val = '✓✓';
                                elseif ($value >= 100) $display_val = '✓';
                                else $display_val = '';
                            } else {
                                $display_val = htmlspecialchars($value);
                                if (strpos($display_val, '✓ (') === 0) {
                                    $display_val = str_replace(['✓ (', ')'], ['✓<br><small>(', ')</small>'], $display_val);
                                }
                                // BARU: Tambahkan kondisi untuk format Qadha yang detail
    elseif (strpos($display_val, 'Q (') === 0) {
        $detail = trim(str_replace(['Q (', ')'], '', $display_val));
        $display_val = 'Q<br><small>(' . htmlspecialchars($detail) . ')</small>';
    }
                            }
                        ?>
                            <td class="<?= getCellColorClass($key, $value) ?>"><?= $display_val ?></td>
                        <?php endfor; ?>
                    </tr>
                    <?php 
                        $is_first_row_in_category = false;
                    endforeach; 
                    ?>
                    
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center;">
             <a href="download.php" class="download-btn">Download Laporan (Excel/CSV)</a>
        </div>
    </div>
    
    <div id="penjelasan-fitur">
        <div class="feature-card">
            <h3><i class="fa-solid fa-palette"></i> Laporan Berwarna</h3>
            <ul>
                <li style="color:var(--color-good-text)"><strong>Hijau:</strong> Amalan tuntas atau dalam kondisi terbaik (misal: Sholat di Masjid berjamaah).</li>
                <li style="color:var(--color-ok-2-text)"><strong>Biru:</strong> Amalan terlaksana dengan baik (misal: Rawatib sebagian, Istighfar > 100).</li>
                <li style="color:var(--color-ok-1-text)"><strong>Kuning:</strong> Amalan terlaksana namun tidak dalam kondisi ideal (misal: Sholat di rumah sendiri ).</li>
                <li style="color:var(--color-qadha-text)"><strong>Merah:</strong> Menandakan Qadha.</li>
            </ul>
        </div>
        <!-- <div class="feature-card">
            <h3><i class="fa-solid fa-pencil-alt"></i> Input Dinamis</h3>
            <p>Form akan terisi otomatis sesuai data pada tanggal yang dipilih. Kosongkan isian untuk menghapus data.</p>
        </div>
        <div class="feature-card">
            <h3><i class="fa-solid fa-list-check"></i> Pelacakan Detail</h3>
            <p>Catat detail sholat Rawatib, jumlah Istighfar, dan surat yang dibaca saat Tilawah untuk evaluasi yang lebih mendalam.</p>
        </div>
        <div class="feature-card">
            <h3><i class="fa-solid fa-file-excel"></i> Download Laporan</h3>
            <p>Unduh rekapitulasi bulanan dalam format CSV yang kompatibel dengan Excel kapan saja.</p>
        </div> -->
        <a href="https://refleksiformentee.xo.je/" target="_blank" rel="noopener noreferrer" style="text-decoration: none; color: inherit;">
    <div class="feature-card">
        <h3><i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Web Refleksi Mentee</h3>
        <p>Buka dan isi platform refleksi untuk mentee di tab baru untuk evaluasi yang lebih baik.</p>
    </div>
</a>
    </div>

</div>

<div class="floating-save-container" id="floating-save-area">
    <div class="container">
        <p><i class="fa-solid fa-triangle-exclamation"></i> Ada perubahan yang belum disimpan.</p>
        <button type="submit" form="form-amalan" class="submit-btn">Simpan Perubahan</button>
    </div>
</div>

<div class="modal-overlay" id="ayamul_bidh_modal">
    <div class="modal-content">
        <button type="button" class="modal-close-btn">&times;</button>
        <h3 id="modal_title"></h3>
        <p id="modal_hadith"></p>
        <p id="modal_desc"></p>
        <h4 id="modal_dates_title"></h4>
        <ul id="modal_dates_list"></ul>
        <p class="disclaimer" id="modal_disclaimer"></p>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const semuaDataAmalan = <?= json_encode($semuaDataAmalan); ?>;
    const form = document.getElementById('form-amalan');
    const tanggalInput = document.getElementById('tanggal');
    const rawatibKeys = <?= json_encode(array_keys($rawatib_details)); ?>;
    const prayerKeys = <?= json_encode(array_keys($daftar_amalan['SHOLAT WAJIB'])); ?>;

    // --- CHANGE DETECTION LOGIC ---
    let initialFormState = '';

    function getCurrentFormState() {
        const data = {};
        // Iterasi melalui semua elemen form untuk memastikan tidak ada yang terlewat
        for (const element of form.elements) {
            if (!element.name || element.type === 'submit' || element.type === 'button') {
                continue;
            }

            if (element.type === 'checkbox') {
                data[element.name] = element.checked;
            } else if (element.type === 'radio') {
                if (element.checked) {
                    data[element.name] = element.value;
                }
            } else {
                data[element.name] = element.value;
            }
        }
        
        // Urutkan key dari object agar hasil stringify konsisten
        const orderedData = {};
        Object.keys(data).sort().forEach(key => {
            orderedData[key] = data[key];
        });

        return JSON.stringify(orderedData);
    }

    window.checkForChanges = function() {
        if (getCurrentFormState() !== initialFormState) {
            document.body.classList.add('show-floating-save');
        } else {
            document.body.classList.remove('show-floating-save');
        }
    }
    
    // --- OPTIONAL DETAILS INPUT LOGIC ---
    document.querySelectorAll('input[type="checkbox"][data-details-wrapper]').forEach(checkbox => {
        const wrapper = document.getElementById(checkbox.dataset.detailsWrapper);
        if(wrapper) {
            checkbox.addEventListener('change', () => {
                wrapper.style.display = checkbox.checked ? 'block' : 'none';
                if (!checkbox.checked) {
                    wrapper.querySelector('input').value = '';
                }
            });
        }
    });

    // --- AYYAMUL BIDH MODAL LOGIC ---
    const ayyamulBidhInfo = <?= json_encode($ayyamul_bidh_info); ?>;
    const modal = document.getElementById('ayamul_bidh_modal');
    const openModalBtn = document.getElementById('ayamul_bidh_info_btn');
    const closeModalBtn = modal.querySelector('.modal-close-btn');

    openModalBtn.addEventListener('click', () => {
        document.getElementById('modal_title').textContent = ayyamulBidhInfo.title;
        document.getElementById('modal_desc').textContent = ayyamulBidhInfo.description;
        document.getElementById('modal_hadith').textContent = ayyamulBidhInfo.hadith;
        document.getElementById('modal_dates_title').textContent = ayyamulBidhInfo.dates_title;
        document.getElementById('modal_disclaimer').textContent = ayyamulBidhInfo.disclaimer;
        
        const list = document.getElementById('modal_dates_list');
        list.innerHTML = '';
        if (ayyamulBidhInfo.dates.length > 0) {
            ayyamulBidhInfo.dates.forEach(dateStr => {
                const li = document.createElement('li');
                li.textContent = dateStr;
                list.appendChild(li);
            });
        } else {
            const li = document.createElement('li');
            li.textContent = "Jadwal tidak tersedia saat ini.";
            list.appendChild(li);
        }
        modal.classList.add('active');
    });
    const closeModal = () => modal.classList.remove('active');
    closeModalBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });


    // --- Quick Navigation Scroll ---
    document.querySelectorAll('.nav-button').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            document.querySelector(targetId).scrollIntoView({ behavior: 'smooth' });
        });
    });

    // --- Istighfar Slider ---
    const istighfarInput = document.getElementById('istighfar');
    const istighfarSlider = document.getElementById('istighfar_slider');
    const istighfarValueDisplay = document.getElementById('istighfar_value');
    istighfarSlider.addEventListener('input', () => {
        istighfarInput.value = istighfarSlider.value;
        istighfarValueDisplay.textContent = istighfarSlider.value;
    });

    // --- MAIN FORM UPDATE FUNCTION ---
    function updateFormForDate(tanggalStr) {
        form.reset(); 
        
        istighfarSlider.value = 0;
        istighfarValueDisplay.textContent = '0';
        prayerKeys.forEach(key => window.setPrayerButtonState(key, ''));
        document.querySelectorAll('.optional-input-wrapper').forEach(w => w.style.display = 'none');


        tanggalInput.value = tanggalStr;

        const bulan = tanggalStr.substring(0, 7);
        const dataBulanIni = semuaDataAmalan[bulan] || {};
        const hari = new Date(tanggalStr + 'T00:00:00').getDate();

        for (const amalanKey in dataBulanIni) {
            if (dataBulanIni[amalanKey] && dataBulanIni[amalanKey][hari] !== undefined) {
                const nilai = dataBulanIni[amalanKey][hari];

                if (prayerKeys.includes(amalanKey)) {
                    window.setPrayerButtonState(amalanKey, nilai);
                    continue; 
                }

                const element = form.elements[amalanKey];
                if (element) {
                     if (element.type === 'checkbox') {
                        const match = typeof nilai === 'string' && nilai.match(/^✓ \((.*)\)$/);
                        if (match) {
                            element.checked = true;
                            const wrapper = document.getElementById(element.dataset.detailsWrapper);
                            if(wrapper) {
                                wrapper.style.display = 'block';
                                wrapper.querySelector('input').value = match[1];
                            }
                        } else {
                           element.checked = (nilai === '✓');
                        }
                        // Trigger change event to show wrapper if checked
                        element.dispatchEvent(new Event('change'));

                    } else if (amalanKey === 'istighfar') {
    // Gunakan 0 jika nilainya "falsy" (seperti string kosong), jika tidak, gunakan nilai itu sendiri.
    const val = nilai || 0; 
    element.value = val;
    istighfarSlider.value = val;
    istighfarValueDisplay.textContent = val;
                    } else if (element.tagName !== 'BUTTON') {
                        element.value = nilai; 
                    }
                }
            }
        }
        
        rawatibKeys.forEach(key => {
            const element = form.elements[key];
            if(element) {
                element.checked = (dataBulanIni[key]?.[hari] === '✓');
            }
        });

        const tilawahValue = dataBulanIni.tilawah?.[hari] || '';
        if (tilawahValue) {
            const parts = tilawahValue.match(/^(.*?)\s*(\d+)-?(\d+)?$/);
            if(parts) {
                form.elements.tilawah_surat.value = parts[1] ? parts[1].trim() : '';
                form.elements.tilawah_ayat_mulai.value = parts[2] || '';
                form.elements.tilawah_ayat_selesai.value = parts[3] || '';
            } else {
                 form.elements.tilawah_surat.value = tilawahValue;
            }
        }

        initialFormState = getCurrentFormState();
        document.body.classList.remove('show-floating-save');
    }

    form.addEventListener('input', checkForChanges);

    tanggalInput.addEventListener('change', function() {
        updateFormForDate(this.value);
    });
    
    // Reminder & Download Button
    const today = new Date();
    const currentDay = today.getDate();
    const reminderContainer = document.getElementById('reminder-container');
    if (currentDay > 25) {
        const monthStr = "<?= $bulan_sekarang ?>";
        reminderContainer.innerHTML = `
            <div class="pesan pesan-pengingat">
                <strong>Pengingat Akhir Bulan!</strong> 
                <span>Jangan lupa untuk mengunduh laporan bulan ini sebelum berganti bulan.</span>
                <a href="download.php?month=${monthStr}" class="download-btn"><i class="fa-solid fa-download"></i> Download Laporan</a>
            </div>`;
    }

    // Initial load
    updateFormForDate(tanggalInput.value);
});
</script>

<?php include __DIR__ . '/qadha_handler.php'; ?>
</body>
</html>