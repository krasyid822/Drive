<?php
// FILE: shortcuts.php

/**
 * Bagian ini mencetak CSS untuk styling ikon shortcut.
 * Didefinisikan sekali saja untuk memastikan tidak ada duplikasi.
 */
if (!defined('SHORTCUT_CSS_INCLUDED')) {
    define('SHORTCUT_CSS_INCLUDED', true);
    echo <<<HTML
<style>
    .legend-shortcut {
        display: inline-block;
        margin-left: 12px;
        color: var(--color-primary);
        text-decoration: none;
        font-size: 0.75em;
        vertical-align: middle;
        opacity: 0.6;
        transition: opacity 0.2s, transform 0.2s;
    }
    .legend-shortcut:hover {
        opacity: 1;
        transform: scale(1.1);
    }
</style>
HTML;
}

/**
 * Fungsi untuk menghasilkan HTML tautan shortcut berdasarkan seksi amalan.
 * @param string $section Nama seksi (cth: 'SHOLAT WAJIB').
 * @return string HTML tag <a> atau string kosong.
 */
function generate_shortcut_link($section) {
    $url = '';
    $tooltip = '';

    switch ($section) {
        case 'SHOLAT WAJIB':
            $url = 'https://krasyid822.github.io/sholatPWA';
            $tooltip = 'Buka panduan Sholat Wajib';
            break;

        case 'ALMATSURAT':
            $url = 'https://krasyid822.github.io/AlMatsurat';
            $tooltip = 'Buka panduan Al-Ma\'tsurat';
            break;

        case 'ISTIGHFAR':
    // Pastikan timezone sudah diatur ke 'Asia/Jakarta' di awal skrip Anda
    // date_default_timezone_set('Asia/Jakarta');

    // Tentukan pagi atau sore berdasarkan jam saat ini
    $hour = (int)date('H');
    $action = ($hour >= 4 && $hour < 12) ? 'pagi' : 'sore'; // Pagi: 04:00 - 11:59

    // Perbarui anchor link dari #istighfar menjadi #amalan-istighfar
    $url = "https://krasyid822.github.io/AlMatsurat?action={$action}#amalan-istighfar";
    
    $tooltip = 'Buka panduan Istighfar di Al-Ma\'tsurat';
    break;
    }

    if (!empty($url)) {
        // Menggunakan ikon dari Font Awesome yang sudah ada di proyek Anda
        return '<a href="' . htmlspecialchars($url) . '" target="_blank" class="legend-shortcut" title="' . htmlspecialchars($tooltip) . '"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>';
    }

    return '';
}
?>