<?php
// FILE: download.php

// --- PENGATURAN DASAR ---
date_default_timezone_set('Asia/Jakarta');
if (!isset($dataFile)) {
    $dataFile = __DIR__ . '/data_amalan.json';
}

// Pastikan struktur ini SAMA PERSIS dengan di index.php
$daftar_amalan = [
    'SHOLAT WAJIB' => [
        'subuh' => 'Subuh', 'dzuhur' => 'Dzuhur', 'ashar' => 'Ashar', 'maghrib' => 'Maghrib', 'isya' => 'Isya'
    ],
    'SHOLAT SUNNAH' => [
        'rawatib' => 'Rawatib', 'dhuha' => 'Dhuha', 'tahajud' => 'Tahajud'
    ],
    'PUASA SUNNAH' => [
        'senin_kamis' => 'Senin/Kamis', 'ayamul_bidh' => 'Ayamul Bidh'
    ],
    'TILAWAH' => [
        'tilawah' => 'Tilawah Quran'
    ],
    'SEDEKAH' => [
        'sedekah' => 'Sedekah'
    ],
    'ALMATSURAT' => [
        'almatsurat_pagi' => 'Al-Matsurat Pagi', 'almatsurat_petang' => 'Al-Matsurat Petang'
    ],
    'ISTIGHFAR' => [
        'istighfar' => 'Istighfar'
    ]
];


function bacaDataAmalan($file) {
    if (!file_exists($file)) return [];
    $dataJson = file_get_contents($file);
    return json_decode($dataJson, true) ?: [];
}

$bulan_diminta = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $bulan_diminta)) {
    die("Format bulan tidak valid.");
}

$semuaDataAmalan = bacaDataAmalan($dataFile);
$dataBulanIni = $semuaDataAmalan[$bulan_diminta] ?? [];
$jumlah_hari = date('t', strtotime($bulan_diminta . '-01'));

$nama_file = "laporan-amalan-" . $bulan_diminta . ".csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $nama_file . '"');

$output = fopen('php://output', 'w');

// Tambahkan BOM untuk kompatibilitas Excel dengan UTF-8
fputs($output, "\xEF\xBB\xBF");

// Header kolom
$header = ['NO', 'IBADAH', 'KETERANGAN'];
for ($i = 1; $i <= $jumlah_hari; $i++) {
    $header[] = $i;
}
fputcsv($output, $header);


// Body data
$nomor = 1;
foreach ($daftar_amalan as $kategori => $sub_kategori) {
    foreach ($sub_kategori as $key => $label) {
        $row = [$nomor, $kategori, $label];
        for ($i = 1; $i <= $jumlah_hari; $i++) {
             $value = $dataBulanIni[$key][$i] ?? '';
             
             // Konversi nilai agar mudah dibaca di Excel
             if (in_array($key, ['dhuha', 'tahajud', 'senin_kamis', 'ayamul_bidh', 'sedekah', 'almatsurat_pagi', 'almatsurat_petang'])) {
                 $display_val = ($value == '✓') ? 'Ya' : '';
             } elseif ($key == 'rawatib') {
                $display_val = $value; // tampilkan x/y
             } elseif ($key == 'istighfar') {
                if ($value >= 200) $display_val = '200';
                elseif ($value >= 100) $display_val = '100';
                else $display_val = ($value > 0) ? $value : '';
             } elseif ($key == 'tilawah') {
                $display_val = $value;
             } else { // Sholat Wajib
                $status_map = [
                    'M' => 'Masjid (Jamaah)', 'R-J' => 'Rumah (Jamaah)',
                    'M-S' => 'Masjid (Sendiri)', 'R' => 'Rumah (Sendiri)', 'Q' => 'Qadha'
                ];
                $display_val = $status_map[$value] ?? '';
             }
            $row[] = $display_val;
        }
        fputcsv($output, $row);
    }
     $nomor++;
}

fclose($output);
exit();
