Karena batasan InfinityFree, file untuk kebutuhan PWA dipisah ke repo github,

https://github.com/krasyid822/Drive

File yang terkait adalah,

manifest.json
android-launchericon-512-512.png
android-launchericon-192-192.png