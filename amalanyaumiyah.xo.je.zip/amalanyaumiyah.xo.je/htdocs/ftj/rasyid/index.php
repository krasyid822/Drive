<?php
// Tentukan URL tujuan redirect
$url_tujuan = "https://amalanyaumiyah.xo.je/test/";

// Lakukan redirect
header("Location: " . $url_tujuan);
exit();
?>
