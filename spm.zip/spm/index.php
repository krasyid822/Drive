<?php
include'koneksi.php';
$tgl=date('Y-m-d');
?>
<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['iduser'])) {
    header("Location: login.php"); // Redirect ke halaman login jika belum login
    exit();
}

// Jika sudah login, lanjutkan tampilan halaman
?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sistem Informasi Perpustakaan</title>
	<link rel="icon" href="images/logo-perpustakaan3.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap-5.3.3-dist/css/bootstrap.css">

</head>
<body >
	<div id="container">
		<div id="header">
			<div id="logo-perpustakaan-container">
				<image id="logo-perpustakaan" src="images/logo-perpustakaan3.png" border=0 style="border:0; text-decoration:none; outline:none"> 
			</div>
			<div id="nama-alamat-perpustakaan-container">
				<div class="nama-alamat-perpustakaan">
					<h1 style="font-family: monomakh; margin-bottom: auto;"><b> PERPUSTAKAAN UMUM </b></h1>
				</div>
				<div class="nama-alamat-perpustakaan">
					<h7>Jl. Almamater, Padang Bulan, Kec. Medan Baru, Kota Medan, Sumatera Utara 20222</h7>
					<!-- <h6>Jl. Lembah Abang No 11, Telp: (021)55555555</h6> -->
				</div>
			</div>
		</div>
		<div id="header2">
			<div id="nama-user"><b><i class="bi bi-person-raised-hand"></i> Hai Admin !</b></div>
		</div>
		<div id="sidebar">
			<a href="index.php?p=beranda"><span class="bi bi-house"></span> Beranda</a>
			<a href="index.php?p=logout"><span class="bi bi-door-open"></span> Log out</a>
			<p class="label-navigasi"><h4>Entry Data dan Transaksi</h4></p>
			<ul>
				<li><a href="index.php?p=anggota"><i class="bi bi-people"></i> Data Anggota</a></li>
				<li><a href="index.php?p=buku"><i class="bi bi-book"></i> Data Buku</a></li>
				<li><a href="index.php?p=transaksi-peminjaman"><i class="bi bi-flag"></i> Transaksi Peminjaman</a></li>
			</ul>
			<p class="label-navigasi"><h4>Laporan</h4></p>
			<ul>
				<li><a href="cetak/cetak-anggota.php"><i class="bi bi-printer"></i> Lap.Data Anggota</a></li>
				<li><a href="cetak/cetak-buku.php"><i class="bi bi-printer"></i> Lap.Data Buku</a></li>
				<!-- <li><a href="cetak/cetak-anggota.php" target="_blank">Lap.Data Anggota</a></li>
				<li><a href="cetak/cetak-buku.php" target="_blank">Lap.Data Buku</a></li> -->
			</ul>
		</div>
		<div id="content-container">
			    <div class="container">
		<div class="row"><br/><br/><br/>
			<div class="col-md-10 col-md-offset-1" style="background-image:url('images/asanoer-background.jpg')">
				<div class="col-md-4 col-md-offset-4">
					<div class="panel panel-warning login-panel" style="background-color:rgba(255, 255, 255, 0.6);position:relative;">
						
						<div class="panel-footer">
							
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
		<?php
			$pages_dir='pages';
			if(!empty($_GET['p'])){
				$pages=scandir($pages_dir,0);
				unset($pages[0],$pages[1]);
				$p=$_GET['p'];
				if(in_array($p.'.php',$pages)){
					include($pages_dir.'/'.$p.'.php');
				}else{
					echo'Halaman Tidak Ditemukan';
				}
			}else{
				include($pages_dir.'/beranda.php');
			}
		?>
		</div>
		<div id="footer"><h5>Sistem Informasi Perpustakaan (SIPUS) | Praktikum </h5></div>
	</div>

	<script src="bootstrap-5.3.3-dist/js/bootstrap.js"></script>
</body>
</html>