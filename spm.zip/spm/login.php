<?php
session_start();
include('koneksi.php'); // File koneksi ke database
$error = "";

// Proses login saat form di-submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari form
    // Walaupun form menggunakan name "nama", field ini berfungsi sebagai ID User (sesuai placeholder "US000")
    $iduser = $_POST['nama'];
    $password = $_POST['password'];
    
    // Siapkan query untuk ambil data user berdasarkan iduser
    $stmt = $db->prepare("SELECT iduser, nama, password FROM tbuser WHERE iduser = ?");
    $stmt->bind_param("s", $iduser);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Jika password disimpan dalam plain text:
        if ($password == $row['password']) {
            // Jika menggunakan password hash, gunakan:
            // if (password_verify($password, $row['password'])) { ... }
            $_SESSION['iduser'] = $row['iduser'];
            $_SESSION['nama'] = $row['nama'];
            header("Location: index.php"); // Ubah ke halaman dashboard atau halaman yang diinginkan
            exit();
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "ID User tidak ditemukan!";
    }
    
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.css">
    <style>
    body {
        background-image: url('images/asanoer-background.jpg'); /* Ganti dengan lokasi gambar */
        background-size: cover; /* Agar gambar menyesuaikan layar */
        background-position: center; /* Agar gambar selalu di tengah */
        background-repeat: no-repeat; /* Jangan ulang gambar */
        height: 100vh; /* Pastikan seluruh layar tertutup */
        /* backdrop-filter: blur(2px); */ /* Efek blur pada background */
    }
    .bg-custom {
        background-color: #da8b16;
        color: white;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5 bg-custom">
                    <div class="card-header">
                        <h2>Login</h2>
                    </div>
                    <div class="card-body">
                        <?php 
                        // Tampilkan error jika ada
                        if (!empty($error)) { 
                            echo "<div class='alert alert-danger'>$error</div>"; 
                        } 
                        ?>
                        <form action="login.php" method="POST">
                            <div class="form-group">
                                <label for="nama">ID User:</label>
                                <input type="text" id="nama" name="nama" class="form-control" placeholder="US000" required>
                            </div>
                            <div class="form-group mt-3">
                                <label for="password">Password:</label>
                                <input type="password" id="password" name="password" class="form-control" placeholder="********">
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Script JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.js"></script>
</body>
</html>
