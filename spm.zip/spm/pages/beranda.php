<html>
	<link rel="stylesheet" type="text/css" href="bootstrap-icons-1.11.3/font/bootstrap-icons.css">
	<style>
    .running-text {
        white-space: nowrap; /* Mencegah teks turun ke bawah */
        overflow: hidden;
        width: 100%; /* Pastikan memenuhi lebar layar */
        position: relative;
        font-size: 20px; /* 20px */
        /* background: yellow; */ /* Bisa dihapus jika tidak butuh warna */
    }

    .running-text::after {
        content: attr(data-text);
        position: absolute;
        width: 100%;
        height: 100%;
        background: inherit;
    }

    @keyframes runText {
        from {
            transform: translateX(100%);
        }
        to {
            transform: translateX(-100%);
        }
    }

    .running-text {
        display: inline-block;
        animation: runText 10s linear infinite;
    }

	.col-container {
        width: 102%; /* Atur lebar kolom */
        height: 23px; /* Atur tinggi kolom */
        /* border: 2px solid black; */
        overflow: hidden;
        position: relative;
        /* background: lightgray; */
    }
</style>
</html>
<div id="label-page"><h3><span class="bi bi-house"></span> Beranda</h3></div>
<div id="content">
	<div class="col-container">
		<div class="running-text">
			<p><i><b>SELAMAT DATANG DI SISTEM INFORMASI PERPUSTAKAAN! "MEMBACA ADALAH JENDELA DUNIA"</b></i></p>
		</div>
	</div>

	<div class="container mt-5">
    <h1 class="mb-4">Buku dari Google Books API</h1>
    <div class="row" id="book-container">
      <!-- Kartu buku akan ditampilkan di sini -->
    </div>
  </div>
  <script>
    // URL Google Books API dengan query "harry potter"
    const apiUrl = 'https://www.googleapis.com/books/v1/volumes?q=hello+world';

    // Dapatkan elemen container untuk menampilkan kartu
    const container = document.getElementById('book-container');

    // Ambil data dari API
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        // Pastikan data.items tersedia
        if (data.items) {
          data.items.forEach(item => {
            const book = item.volumeInfo;
            // Cek apakah ada thumbnail
            const thumbnail = book.imageLinks ? book.imageLinks.thumbnail : 'https://via.placeholder.com/128x195?text=No+Image';

            // Buat elemen kolom untuk Bootstrap
            const col = document.createElement('div');
            col.className = 'col-md-4 mb-4';

            // Masukkan HTML kartu
            col.innerHTML = `
              <div class="card h-100">
                <img src="${thumbnail}" class="card-img-top" alt="${book.title}">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">${book.title}</h5>
                  <p class="card-text">${book.description ? book.description.substring(0, 100) + '...' : 'Tidak ada deskripsi.'}</p>
                  <a href="${book.infoLink}" target="_blank" class="btn btn-primary mt-auto">Baca Selengkapnya</a>
                </div>
              </div>
            `;

            // Tambahkan kolom ke container
            container.appendChild(col);
          });
        } else {
          container.innerHTML = '<p>Tidak ditemukan buku.</p>';
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        container.innerHTML = '<p>Terjadi kesalahan saat mengambil data.</p>';
      });
  </script>
	
	<!-- 
	<div id="beranda-judul">
		<h1>SELAMAT DATANG DI SISTEM INFORMASI PERPUSTAKAAN</h1>
	</div>
	<div id="beranda-konten">
		<h2>"MEMBACA ADALAH JENDELA DUNIA"</h2>
	</div> -->
</div>