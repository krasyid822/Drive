<html>
	<link rel="stylesheet" type="text/css" href="bootstrap-icons-1.11.3/font/bootstrap-icons.css">
</html>
<div id="label-page"><h3><i class="bi bi-book"></i> Tampil Data Buku</h3></div>
<div id="content">
	<p id="tombol-tambah-container"><a href="index.php?p=buku-input" class="btn btn-outline-primary">Tambah Buku</a></p>
	<table id="tabel-tampil">
		<tr>
			<th id="label-tampil-no">No</td>
			<th>ID Buku</th>
			<th>Judul</th>
			<th>Kategori</th>
			<th>Pengarang</th>
			<th>Penerbit</th>
			<th>Status</th>
			<th id="label-opsi">Opsi</th>
		</tr>
		<?php
		$sql="SELECT * FROM tbbuku ORDER BY idbuku DESC";
		$q_tampil_buku = mysqli_query($db, $sql);
		
		$nomor=1;
		while($r_tampil_buku=mysqli_fetch_array($q_tampil_buku)){
		?>
		<tr>
			<td><?php echo $nomor++; ?></td>
			<td><?php echo $r_tampil_buku['idbuku']; ?></td>
			<td><?php echo $r_tampil_buku['judul']; ?></td>
			<td><?php echo $r_tampil_buku['kategori']; ?></td>
			<td><?php echo $r_tampil_buku['pengarang']; ?></td>
			<td><?php echo $r_tampil_buku['penerbit']; ?></td>
			<td><?php echo $r_tampil_buku['status']; ?></td>
			<td>
				<div class="btn-group" role="group" aria-label="Basic example">
					<button type="button" class="btn btn-outline-secondary" onclick="window.location.href='index.php?p=buku-edit&id=<?php echo $r_tampil_buku['idbuku'];?>';">Edit</button>
					<button type="button" class="btn btn-danger" onclick="window.location.href='proses/buku-hapus.php?id=<?php echo $r_tampil_buku['idbuku']; ?>';">Hapus</button>
				</div>
			</td>
		</tr>
		<?php } ?>
	</table>
</div>