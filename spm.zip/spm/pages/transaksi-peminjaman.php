<html>
	<link rel="stylesheet" type="text/css" href="bootstrap-icons-1.11.3/font/bootstrap-icons.css">
</html>
<div id="label-page"><h3><i class="bi bi-flag"></i> Tampil Data Peminjaman</h3></div>
<div id="content">
	<p id="tombol-tambah-container"><a href="index.php?p=peminjaman-input" class="btn btn-outline-primary">Tambah Peminjaman</a></p>
	<table id="tabel-tampil">
		<tr>
			<th id="label-tampil-no">No</td>
			<th>ID Peminjaman</th>
			<th>Nama Anggota</th>
			<th>Nama Buku</th>
			<th>Tanggal Peminjaman</th>
			<th>Tanggal Kembali</th>
			<th id="label-opsi">Opsi</th>
		</tr>
		

		
		<?php
		$sql="SELECT * FROM tbpeminjaman ORDER BY idpeminjaman DESC";
		$q_tampil_peminjaman = mysqli_query($db, $sql);

		$nomor=1;
		while(
            $r_tampil_peminjaman=mysqli_fetch_array($q_tampil_peminjaman)
            ){
		?>
		<tr>
			<td><?php echo $nomor++; ?></td>
			<td><?php echo $r_tampil_peminjaman['idpeminjaman']; ?></td>
			<td><?php 
            $sql1="SELECT * FROM tbanggota ORDER BY idanggota DESC";
            $q_tampil_anggota = mysqli_query($db, $sql1);
            $r_tampil_anggota=mysqli_fetch_array($q_tampil_anggota);
            echo $r_tampil_anggota['nama']; ?></td>
			<td><?php 
            $sql2="SELECT * FROM tbbuku ORDER BY idbuku DESC";
            $q_tampil_buku = mysqli_query($db, $sql2);
            $r_tampil_buku=mysqli_fetch_array($q_tampil_buku);
            echo $r_tampil_buku['judul']; ?></td>
			<td><?php echo $r_tampil_peminjaman['tglpinjam']; ?></td>
			<td><?php echo $r_tampil_peminjaman['tglkembali']; ?></td>
			<td>
				<div class="btn-group" role="group" aria-label="Basic example">
					<button type="button" class="btn btn-outline-secondary" onclick="window.location.href='index.php?p=peminjaman-edit&id=<?php echo $r_tampil_peminjaman['idpeminjaman'];?>';">Edit</button>
					<button type="button" class="btn btn-danger" onclick="window.location.href='proses/peminjaman-hapus.php?id=<?php echo $r_tampil_peminjaman['idpeminjaman']; ?>';">Hapus</button>
				</div>
			</td>
		</tr>
		<?php } ?>
	</table>
</div>