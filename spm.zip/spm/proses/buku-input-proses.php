<?php
include'../koneksi.php';
$a=$_POST['id_buku'];
$b=$_POST['judul'];
$c=$_POST['kategori'];
$d=$_POST['pengarang'];
$e=$_POST['penerbit'];
$f=$_POST['status'];
	
if(isset($_POST['simpan'])){

	$sql = 
	"INSERT INTO tbbuku
		VALUES('$a','$b','$c','$d','$e','$f')";
	$query = mysqli_query($db, $sql);

	header("location:../index.php?p=buku");
}
?>