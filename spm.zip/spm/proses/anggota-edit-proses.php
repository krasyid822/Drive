<?php
include'../koneksi.php';

$a=$_POST['id_anggota'];
$b=$_POST['nama'];
$c=$_POST['jenis_kelamin'];
$d=$_POST['alamat'];
$e=$_POST['status'];

If(isset($_POST['simpan'])){
	mysqli_query($db,
		"UPDATE tbanggota
		SET nama='$b',jeniskelamin='$c',alamat='$d',status='$e'
		WHERE idanggota='$a'"
	);
	header("location:../index.php?p=anggota");
}
?>