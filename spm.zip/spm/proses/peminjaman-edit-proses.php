<?php
include'../koneksi.php';

$a=$_POST['id_peminjaman'];
$b=$_POST['idanggota'];
$c=$_POST['idbuku'];
$d=$_POST['tglpinjam'];
$e=$_POST['tglkembali'];

If(isset($_POST['simpan'])){
	mysqli_query($db,
		"UPDATE tbpeminjaman
		SET idanggota='$b',idbuku='$c',tglpinjam='$d',tglkembali='$e'
		WHERE idpeminjaman='$a'"
	);
	header("location:../index.php?p=transaksi-peminjaman");
}
?>