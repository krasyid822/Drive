<?php
include'../koneksi.php';
$a=$_POST['id_peminjaman'];
$b=$_POST['idanggota'];
$c=$_POST['idbuku'];
$d=$_POST['tglpinjam'];
$e=$_POST['tglkembali'];
	
if(isset($_POST['simpan'])){

	$sql = 
	"INSERT INTO tbpeminjaman
		VALUES('$a','$b','$c','$d','$e')";
	$query = mysqli_query($db, $sql);

	header("location:../index.php?p=transaksi-peminjaman");
}
?>