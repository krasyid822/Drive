<?php
include'../koneksi.php';

$a=$_POST['id_buku'];
$b=$_POST['judul'];
$c=$_POST['kategori'];
$d=$_POST['pengarang'];
$e=$_POST['penerbit'];
$f=$_POST['status'];

If(isset($_POST['simpan'])){
	mysqli_query($db,
		"UPDATE tbbuku
		SET judul='$b',kategori='$c',pengarang='$d',penerbit='$e',status='$f'
		WHERE idbuku='$a'"
	);
	header("location:../index.php?p=buku");
}
?>