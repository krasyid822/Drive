<?php
include'../koneksi.php';
$a=$_POST['id_anggota'];
$b=$_POST['nama'];
$c=$_POST['jenis_kelamin'];
$d=$_POST['alamat'];
$e=$_POST['status'];
	
if(isset($_POST['simpan'])){

	$sql = 
	"INSERT INTO tbanggota
		VALUES('$a','$b','$c','$d','$e')";
	$query = mysqli_query($db, $sql);

	header("location:../index.php?p=anggota");
}
?>