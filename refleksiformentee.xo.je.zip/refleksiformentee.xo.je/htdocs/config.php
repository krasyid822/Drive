<?php
// Pengaturan Database
define('DB_SERVER', 'sql100.infinityfree.com');
define('DB_USERNAME', 'if0_37577629'); // Ganti dengan username database Anda
define('DB_PASSWORD', 'nz8RyTFiqo6'); // Ganti dengan password database Anda
define('DB_NAME', 'if0_37577629_refleksiformentee'); // Ganti dengan nama database Anda

// BARIS BARU: Tambahkan API Key Gemini Anda di sini
define('GEMINI_API_KEY', 'AIzaSyDfKeS0JklWGFu6kXMk882y6GCm5I3f01E'); // <-- GANTI DENGAN API KEY ANDA

// Membuat koneksi ke database
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>
