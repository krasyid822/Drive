#!/sbin/sh
# BY Astrako / ukazxda
SYSTEMSIZE=3500
SGDISK=/tmp/sgdisk
DISK=/dev/block/mmcblk0
DISKCODE=`$SGDISK --print $DISK | grep SYSTEM | awk '{printf $6}'`

function delete() {
	# Delete partitions
	$SGDISK --delete=$1 $DISK
}
function calculate() {
	# Get SYSTEM partition number and delete it
	SYSPART=`$SGDISK --print $DISK | grep SYSTEM | awk '{printf $1}'`
	delete $SYSPART
	# Get USERDATA partition number and delete it
    DATAPART=`$SGDISK --print $DISK | grep USERDATA | awk '{printf $1}'`
	delete $DATAPART
}
function repart() {	
	# SYSTEM repartition
    $SGDISK --new=0:0:+${SYSTEMSIZE}Mib --typecode=0:$DISKCODE --change-name=0:SYSTEM $DISK
	#USERDATA repartition
	$SGDISK --new=0:0:0 --typecode=0:$DISKCODE --change-name=0:USERDATA $DISK
}
# main
calculate
repart
